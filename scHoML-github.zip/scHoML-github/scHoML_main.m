function [c] = scHoML_main(dataset,k,dimH)
%SCHOML_MAIN  
%% Parameters 

%% Y--Y is the multimodal data, can be normalized/ dimension reduced.
% Format: Y is a cell object; composed of V modals; Y{i} is of n*di dimensionality;

%% k-- k is the KNN parameter for KNN-Graph construction in Laplacian Matrix;
% Format: k is an integer number

%% dimH-- dimH is the unified dimension number for single cell multi-omics data.
% Format: dim is an integer number

%% clusterno-- clusterno is the clustering number for the integrated multi-omics data in low-dimensional space
% Format: clusterno is an integer number

%% true_label-- true_label is the groundtrurh for differentiating cells in the parallelled multi-omics data.
% Format: true_label is a vector of dimension n (n is the number of cells)
%   �˴���ʾ��ϸ˵��
addpath('./preprocessed_data');
load(['preprocessed_' dataset]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Estimate cluster number
[L,H]=LaplacianOptimization(Y,k,dimH,k);

%% Clustering Analysis
for clusterno = 1:10
d=pdist([H+conj(H)]/2,'correlation');
z=linkage(d);
c = cluster(z,'maxclust',clusterno);
clust(:,clusterno)=c;
true_labelc = cell(length(c),1);
for i=1:length(c)
    true_labelc{i}=num2str(true_label(i));
end
%% Accuracy Evaluation
if size(c,2)~=1
    reshape(c,length(c),1);
end
if size(true_label,2)~=1
    reshape(true_label,length(true_label),1);
end

end

eva= evalclusters(H+conj(H),clust,'Silhouette');
clusterno=eva.OptimalK;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Clustering  Analysis

d=pdist([H+conj(H)]/2,'correlation');
z=linkage(d);
c = cluster(z,'maxclust',clusterno);

true_labelc = cell(length(c),1);
for i=1:length(c)
    true_labelc{i}=num2str(true_label(i));
end
%% Accuracy Evaluation
if size(c,2)~=1
    reshape(c,length(c),1);
end
if size(true_label,2)~=1
    reshape(true_label,length(true_label),1);
end

end

