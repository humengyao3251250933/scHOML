function [c,H] = scHoML_mainL(dataset,k,dimH)
%SCHOML_MAINL 
%   for multi-omics data involving relatively large number of cells
addpath('./preprocessed_data');
load(['preprocessed_' dataset]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% High order Laplacian Matrix Optimization and Embedding
[L,H]=LaplacianOptimization(Y,k,dimH,k);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Estimate cluster number
for clusterno = 1:10
d=pdist([H+conj(H)]/2,'cityblock');
z=linkage(d,'average');
c = cluster(z,'maxclust',clusterno);
clust(:,clusterno)=c;


true_labelc = cell(length(c),1);
for i=1:length(c)
    true_labelc{i}=num2str(true_label(i));
end

end

nX1=X1';
[snx,indx1]=sort(-std(nX1));
nX2=X2';
[snx2,indx2]=sort(-std(nX2));

 for run=1:10
eva= evalclusters(nX1(:,indx1(1:run)),clust,'CalinskiHarabasz');
cooo1(run)=eva.OptimalK;
end
for run=1:10
eva= evalclusters(nX2(:,indx2(1:run)),clust,'CalinskiHarabasz');
cooo2(run)=eva.OptimalK;

end
CC=tabulate([cooo1 cooo2]);
clusterno=find(CC(:,3)==max(CC(:,3)));


d=pdist([H+conj(H)]/2,'cityblock');
z=linkage(d,'average');
c = cluster(z,'maxclust',clusterno);


