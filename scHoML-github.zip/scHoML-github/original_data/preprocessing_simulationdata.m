function [Y,true_label]=preprocessing_simulationdata()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load data_sim2;

load data_sim;
X{1}=X1';
X{2}=X2';

V=length(X);
n=size(X{1},1);
Y=cell(V,1);

for v=1:V
    temp = X{v};
    [s,ind]=sort(-std(temp));
    X{v}=temp(:,ind(1:min(length(s))));
end

for v=1:V
    X_mean=zeros(1,size(X{v},2));
    for i=1:n
       X_mean=X_mean+X{v}(i,:);
    end
    X_mean=X_mean/n;
    
    sigma=0;
    for i=1:n
        sigma=sigma+(norm(X{v}(i,:)-X_mean))^2;
    end
    sigma=sqrt(sigma/(n-1));

    for i=1:n
        X{v}(i,:)= (X{v}(i,:)-X_mean)/sigma;
    end
      [a,Yt]=pca1(X{v});
      Y{v}=Yt(:,1:5);
end
filename = './preprocessed_data/preprocessed_sim';
save(filename, 'Y', 'true_label')