%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load pbmc_10xoriginal;

X1=csvread('Protein.csv',1,1);
X2=csvread('RNA500.csv',1,1);
load truth10X10k;
newtruth = truth10X10k;
label=zeros(length(newtruth),1);
label(strcmp('B cells',newtruth))=1;
label(strcmp('CD14+ monocytes',newtruth))=2;
label(strcmp('CD16+ monocytes',newtruth))=3;
label(strcmp('CD4+ T cells',newtruth))=4;
label(strcmp('CD8+ T cells',newtruth))=5;
label(strcmp('Dendritic cells',newtruth))=6;
label(strcmp('NK cells',newtruth))=7;
label(strcmp('Unknown',newtruth))=0;
newprotein = X1(:,find(label~=0));
newrna = X2(:,find(label~=0));
true_label = label(find(label~=0));
X1 = newprotein;
X2 = newrna;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Needs installation of drtoolbox
Y{1}=compute_mapping(X1','DiffusionMaps',10);
Y{2}=compute_mapping(X2','DiffusionMaps',60);

filename = './preprocessed_data/preprocessed_pbmc10x';
save(filename, 'Y', 'X1','X2','true_label')

