function [L,H]=LaplacianOptimization(X,K,C,a)

% 在原作者方法基础上考虑一二阶拉普拉斯矩阵的线性组合

% X是元胞数组，用以存储不同视图的数据集。
% 给定V个视图的数据集X1,X2,...,XV后，可以令X=cell(V,1),再分别令X{i}=Xi储存起来
% 数据集Xi是N*Di维数据，N是数据个数，Di是每个数据维数
% K为K近邻所需的K，C为想要的聚类个数，a为优化问题第三项要输入的参数
% 输出：L为最终确认的拉普拉斯矩阵，由谱聚类相关知识，H为最终聚类所需要的矩阵
tic

V=length(X);
A1=cell(V,1); % 存储各个视图的一阶邻接矩阵
A2=cell(V,1); % 存储各个视图的二阶邻接矩阵
L1=cell(V,1); % 存储各个视图的一阶拉普拉斯矩阵
L2=cell(V,1); % 存储各个视图的二阶拉普拉斯矩阵

for i=1:V
    A1{i}=one_order_adjacent_matrix(X{i},K);
    A2{i}=two_order_adjacent_matrix(X{i},K);
    L1{i}=one_order_Laplacian_matrix(X{i},K);
    L2{i}=two_order_Laplacian_matrix(X{i},K);
end

%得到优化问题第三项所需的矩阵M
M=zeros(V,V);
for i=1:V
    for j=1:V
        M(i,j)=trace(A1{i}*A1{j})/(norm(A1{i},'fro')*(norm(A1{j},'fro')))+trace(A2{i}*A2{j})/(norm(A2{i},'fro')*(norm(A2{j},'fro')));
    end
end

% 初始化参数
% 由于倒V打不了。。用G表示原问题的倒V
% 将问题所需的H,W初始化为零矩阵，u的每个分量初始化为1/V，G初始化为C维单位阵，lamda初始化为1/2
n=size(X{1},1); %数据集中数据的个数
H=zeros(n,C);
W=zeros(n,C);
u=ones(V,1)/V;
G=eye(C);
lamda=1/2;
t=0; %计算迭代次数

% 初始化一阶和二阶拉普拉斯矩阵的线性组合
L_u_1=zeros(n);
L_u_2=zeros(n);
for i=1:V
      L_u_1=L_u_1+u(i)*L1{i};
      L_u_2=L_u_2+u(i)*L2{i};
end

%初始化目标函数
obj1=(norm(eye(n)-lamda*L_u_1-(1-lamda)*L_u_2,'fro'))^2+a*u'*M*u;
obj2=0;


%交替优化步骤开始
while (abs(obj1-obj2))>=10^(-4)*abs(obj1)

% 更新一阶和二阶拉普拉斯矩阵的线性组合
    L_u_1=zeros(n);
    L_u_2=zeros(n);
    for i=1:V
        L_u_1=L_u_1+u(i)*L1{i};
        L_u_2=L_u_2+u(i)*L2{i};
    end
%更新lamda
    AA=trace(L_u_1*L_u_1-L_u_1*L_u_2-L_u_2*L_u_1+L_u_2*L_u_2);
    BB=trace(L_u_1*L_u_2+L_u_2*L_u_1-2*L_u_2*L_u_2-2*(eye(n)-W*G*W')*(L_u_1-L_u_2));
    if AA>0
       if -BB/(2*AA)<0
          lamda=0;
       elseif -BB/(2*AA)>1
          lamda=1;
       else
          lamda=-BB/(2*AA);
       end
    else
        if AA+BB<0
            lamda=1;
        else
            lamda=0;
        end
    end

% 更新W
    B=lamda*L_u_1+(1-lamda)*L_u_2-1/2*(H*H');
    [bb,~]=eig(B);
    for j=1:C
        W(:,j)=bb(:,j);
    end
%     for i=1:n
%         for j=1:C
%             W(i,j)=bb(i,j);
%         end
%     end

%更新G（也就是倒V）
    C1=W'*(lamda*L_u_1+(1-lamda)*L_u_2-1/2*(H*H'))*W-eye(C); %可以留意一下eye(C)前面有没有2，应该是没的，2写在外面
    for i=1:C
        if C1(i,i)>0
            G(i,i)=0;
        elseif C1(i,i)<-1
            G(i,i)=1;
        else
            G(i,i)=-C1(i,i);
        end
    end

% 更新H
    [Y,~]=eig(eye(n)-W*G*W');
    for j=1:C
        H(:,j)=Y(:,j);
    end
%     for i=1:n
%         for j=1:C
%             H(i,j)=Y(i,j);
%         end
%     end

% 更新u
    T=zeros(V,1);
    M1=zeros(V,V);
    for i=1:V
        T(i)=trace((eye(n)-W*G*W')*(lamda*L1{i}+(1-lamda)*L2{i}));
        for j=1:V
            M1(i,j)=trace(lamda^2*L1{i}*L1{j}+lamda*(1-lamda)*L1{i}*L2{j}+lamda*(1-lamda)*L2{i}*L1{j}+(1-lamda)^2*L2{i}*L2{j});
        end
    end
    u=quadprog(a*M+M1+conj(a*M+M1),-T-conj(T),[],[],ones(1,V),1,zeros(V,1),ones(V,1));
    
   % u=quadprog(a*M+M1,-2*T,[],[],ones(1,V),1,zeros(V,1),ones(V,1));% 0330


% 更新lamda
%     AA=trace(L_u_1*L_u_1-L_u_1*L_u_2-L_u_2*L_u_1+L_u_2*L_u_2);
%     BB=trace(L_u_1*L_u_2+L_u_2*L_u_1-2*L_u_2*L_u_2-2*(eye(n)-W*G*W')*(L_u_1-L_u_2));
%     if AA>0
%        if -BB/(2*AA)<0
%           lamda=0;
%        elseif -BB/(2*AA)>1
%           lamda=1;
%        else
%           lamda=-BB/(2*AA);
%        end
%     else
%         if AA+BB<0
%             lamda=1;
%         else
%             lamda=0;
%         end
%     end


% 迭代次数增加
    t=t+1;
% 更新目标函数值
    obj2=obj1;
    obj1=trace(H'*(eye(n)-W*G*W')*H)+(norm(eye(n)-W*G*W'-lamda*L_u_1-(1-lamda)*L_u_2,'fro'))^2+a*u'*M*u;
end

% 最终得到的拉普拉斯矩阵
L=eye(n)-W*G*W';
[H1,~]=eig(L);
for j=1:C
    H(:,j)=H1(:,j);
end
%  for i=1:n
%         for j=1:C
%             H(i,j)=H1(i,j);
%         end
%  end
end