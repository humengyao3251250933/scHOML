function [A] = Gausskernel(X)
% 这是高斯核函数
% 输入：数据集，N*D维数据，N是数据个数，D是每个数据维数
% 输出：A 相似性矩阵
n=size(X,1);
A=zeros(n);
%计算方差sigma
X_mean=zeros(1,size(X,2));
sigma=0;
for i=1:n
    X_mean=X_mean+X(i,:);
end
X_mean=X_mean/n;
for i=1:n
    sigma=sigma+(norm(X(i,:)-X_mean))^2;
end
sigma=sigma/(n-1);

%注意！！！！！sigma已经是平方后的了！！！！！！

%计算相似性矩阵A的各元素
for i=1:n
    for j=1:n
        A(i,j)=exp(-norm(X(i,:)-X(j,:))^2/(2*sigma));
        %A(i,j)=exp(-1/2*(norm(X(i,:)-X(j,:)))^2);
        %A(i,j)=norm(X(i,:)-X(j,:));
    end
    A(i,i)=0;  
end
end


