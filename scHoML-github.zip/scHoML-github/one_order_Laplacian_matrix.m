function [L1]=one_order_Laplacian_matrix(X,K)
% 输入：数据集，N*D维数据，N是数据个数，D是每个数据维数
%       和K近邻所需的K
% 输出：一阶拉普拉斯矩阵
A=one_order_adjacent_matrix(X,K);
D=diag(sqrt(sum(A,2).^(-1)));
L1=eye(size(A))-D*A*D;
end