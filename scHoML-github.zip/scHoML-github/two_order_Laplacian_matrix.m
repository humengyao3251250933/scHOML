function [L2]=two_order_Laplacian_matrix(X,K)
% 输入：数据集，N*D维数据，N是数据个数，D是每个数据维数
%       和K近邻所需的K
% 输出：二阶拉普拉斯矩阵
A2=two_order_adjacent_matrix(X,K);
D2=diag(sqrt(sum(A2,2).^(-1)));
L2=eye(size(A2))-D2*A2*D2;
end
