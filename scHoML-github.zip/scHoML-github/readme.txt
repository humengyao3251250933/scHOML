%scHoML is proposed for integrating multi-omics data
%There are different data sets: simulation data and PBMC_10X data etc for  demonstration.
scHoML_main/ scHoML_mainL is for whole integration and heterogeneity analysis.

