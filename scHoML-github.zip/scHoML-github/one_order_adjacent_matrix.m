function [A]=one_order_adjacent_matrix(X,K)
% 输入：数据集，N*D维数据，N是数据个数，D是每个数据维数
%       和K近邻所需的K
% 输出：基于KNN的邻接矩阵A
A1= Gausskernel(X);
n=size(A1);
A=A1;
%找到K近邻
[~,index]=sort(A1,1,'descend'); %按列根据相似性由大到小重新排列，index是重排的编号
KNNindex = index(1:K, :);%去掉自己与自己相似性1的编号,得到K近邻的的编号
% 对于每个数据i，将与不是K近邻的数据j之间的相似性A(i,j)改成0
for i=1:n
    for j=1:n
        a=0;
        for m=1:K
            if KNNindex(m,i)==j || KNNindex(m,j)==i
                a=1;
                break
            end
        end
        if a==0
            A(i,j)=0;
        end
    end
end
end

