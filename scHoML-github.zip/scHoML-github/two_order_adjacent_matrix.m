function [A2]=two_order_adjacent_matrix(X,K)
% 输入：数据集，N*D维数据，N是数据个数，D是每个数据维数
%       和K近邻所需的K
% 输出：二阶邻接矩阵
A1=one_order_adjacent_matrix(X,K);
n=size(A1);
A2=zeros(n);
for i=1:n
    for j=1:n
        A2(i,j)=A1(:,i)'*A1(:,j);
    end
end
end